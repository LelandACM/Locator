#include "ros/ros.h"
#include "sensor_msgs/LaserScan.h"
#include "std_msgs/String.h"
#include "msg2tcp/BinaryInterfaceServer.h"
#include "msg2tcp/LaserServer.h"
#include "tf/transform_datatypes.h"
#include "cmath"
//Open the socket

LaserServer::LaserServer(int port): port_(port), laser_number_(0){
  server_ = new BinaryInterfaceServer(port);
}

/*void LaserServer::updateLaser(const LaserMessage laser_message) {
  laser_number_++;
  LaserMessage data = laser_message;
  data.scanNum = laser_number_;
  server_->write(&data, sizeof(data));
}*/


void LaserServer::updateLaser(const LaserMessage laser_message) {
  //laser_number_++;
  //LaserMessage data = laser_message;
  //LaserMessage laser_message;
  //data.scanNum = laser_number_;
  int buffer_size = sizeof(float)*laser_message.ranges.size() + 83;
  int index = 0;
  char* p = (char*)malloc(buffer_size);
  memcpy(p+index, &laser_message.scanNum, 2);
  index += 2;
  memcpy(p+index, &laser_message.time_start, 8);
  index += 8;
  memcpy(p+index, &laser_message.uniqueId, 8);
  index += 8;
  memcpy(p+index, &laser_message.duration_beam, 8);
  index += 8;
  memcpy(p+index, &laser_message.duration_scan, 8);
  index += 8;
  memcpy(p+index, &laser_message.duration_rotate, 8);
  index += 8;
  memcpy(p+index, &laser_message.numBeams, 4);
  index += 4;
  memcpy(p+index, &laser_message.angleStart, 4);
  index += 4;
  memcpy(p+index, &laser_message.angleEnd, 4);
  index += 4;
  memcpy(p+index, &laser_message.angleInc, 4);
  index += 4;
  memcpy(p+index, &laser_message.minRange, 4);
  index += 4;
  memcpy(p+index, &laser_message.maxRange, 4);
  index += 4;
  memcpy(p+index, &laser_message.rangeArraySize, 4);
  index += 4;
  for (auto rang : laser_message.ranges) {
    memcpy(p+index, &rang, 4);
    index += 4;
  }
  memcpy(p+index, &laser_message.hasIntensities, 1);
  index += 1;
  memcpy(p+index, &laser_message.minIntensities, 4);
  index += 4;
  memcpy(p+index, &laser_message.maxIntensities, 4);
  index += 4;
  memcpy(p+index, &laser_message.intensitiesArraySize, 4);
  server_->write(p, buffer_size);
  free(p);
}

//Broadcast to all clients the laser data 
uint16_t currentScanNum   {0}; //Initialize scan number from 0 
void scanCallback(const sensor_msgs::LaserScan::ConstPtr& msg, LaserServer* pToLaserServer)
{ 
  int inf_num = 0; //Count number of inf in the ranges
  int nan_num = 0; //Count number of nan in the ranges

  std::cout << "***********************************************" << std::endl;
  ROS_INFO("trigger");
  LaserMessage laser_message;
  const std::chrono::duration<double> unixTimePoint = std::chrono::system_clock::now() - std::chrono::system_clock::time_point ();
  //double unix_UTC = std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
  laser_message.scanNum = ++currentScanNum; //Accumulate scan number as ID of scans
  //laser_message.scanNum = msg->seq;
  laser_message.time_start = unixTimePoint.count();
  //laser_message.time_start = unix_UTC / 1000000.; 
  //laser_message.time_start = msg->header.stamp.toSec();    
  //laser_message.time_start = ros::Time::now();                                     
  laser_message.numBeams = laser_message.rangeArraySize = msg->ranges.size();                     //rangeSize get from ros message
  if ((msg->angle_min < -3.1415926) ||(msg->angle_max > 3.1415926))                               //angleRange is limited to -pi to pi
  {
    laser_message.angleStart = (0-(msg->angle_max - msg->angle_min)/2);                           //angleStart by rearrange
  }
  else
  {
    laser_message.angleStart = msg->angle_min;                                                    //angleStart get from ros message
  }                                                   
  laser_message.angleInc = msg->angle_increment;                                                  //angleIncrement get from ros message
  laser_message.angleEnd = laser_message.angleStart + msg->angle_increment * (laser_message.numBeams - 1);
  //laser_message.angleEnd = msg->angle_min + msg->angle_increment * (laser_message.numBeams - 1);  //calculate angleEnd by equation
  laser_message.minRange = msg->range_min;                                                        //constant
  laser_message.maxRange = msg->range_max;                                                        //constant
  // laser_message.duration_beam = beamDurationInSec;
  // laser_message.duration_scan = scanDurationInSec;
  // laser_message.duration_rotate = rotationDurationInSec;
  //std::cout<<"  msg->scan_time time before change  "<< msg->scan_time <<std::endl;
  laser_message.duration_rotate = msg->scan_time; 
  //laser_message.duration_rotate = 0.05;                //time of one full rotate
  //if (msg->scan_time < 0.01) { laser_message.duration_rotate = 1/20; }   //if time of one full rotate is not given, set documented frequency
  laser_message.duration_scan = laser_message.duration_rotate * ((laser_message.angleEnd - laser_message.angleStart) / 6.283185307); //calculate scan time 
  laser_message.duration_beam = laser_message.duration_scan/laser_message.numBeams;                                                  //calculate duration of each beam by dividing scan duration
  

  printf("scanNum: %d\n", laser_message.scanNum);
  //check time
  //std::cout << laser_message.time_start << std::endl;
  printf("Current time: %f\n",laser_message.time_start);
  std::cout << "Start angle: " << laser_message.angleStart << std::endl;
  std::cout << "Angle min: " << msg->angle_min << std::endl;
  std::cout << "End angle: " << laser_message.angleEnd << std::endl;
  std::cout << "Angle max: " << msg->angle_max << std::endl;
  std::cout << "Number of beams: " << msg->ranges.size() << std::endl;
  printf("msg header time: %f\n",msg->header.stamp.toSec());
  //check frequency and number of beams
  std::cout<<" One rotation time after change: "<< laser_message.duration_rotate <<std::endl;
  std::cout<<" Frequence(Hz): " << 1 /laser_message.duration_rotate  << std::endl;
  std::cout <<" Number of Beams: " << laser_message.numBeams << std::endl;
  for (size_t i = 0; i < laser_message.numBeams; ++i)
      {
        ///laser_message.ranges[i] = msg->ranges[i];
        //std::cout << typeid(msg->ranges[i]).name() << std::endl;
        if (msg->ranges[i] == +1.0/0.0) 
        {
          inf_num = inf_num +1;
          laser_message.ranges.push_back(msg->range_max);
        }
        else if(msg->ranges[i] != msg->ranges[i])
        {
          nan_num = nan_num +1 ; 
	        laser_message.ranges.push_back(msg->range_min);
	      }/*
        else if(msg->ranges[i] > 100)
        {
          laser_message.ranges.push_back(msg->range_max);
        }*/
        else{
          //  std::cout << "the range is not infinite:  " << msg->ranges[i] << std::endl;
          laser_message.ranges.push_back(msg->ranges[i]);  //if it's inf, send max value instead
        }
        
        //laser_message.ranges.push_back(msg->ranges[i]);
        //std::cout << msg->ranges[i] << std::endl; 
      }


  std::cout << "Note: Num of inf is "<< inf_num <<" , Num of nan is "<< nan_num<<std::endl;
  std::cout << "Set all Inf to range_max and Nan to range_min ."<<std::endl;
  pToLaserServer->updateLaser(laser_message);

}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "laser2tcp_node");
    ros::NodeHandle n("~");

    int port = 9090;
    std::string laser_topic = "/scan";
    // std_msgs::String ip;

    if (n.getParam("port", port))
    {
      ROS_INFO("Got 'port' param: %d", port);
    }
    else
    {
      ROS_ERROR("Failed to get param 'port'");
    }

    if (n.getParam("laser_topic", laser_topic))
    {
      ROS_INFO("Got 'laser_topic' param: %s", laser_topic.c_str());

    }
    else
    {
      ROS_ERROR("Failed to get param 'laser_topic'");

    }

    // LaserServer* odom_server_ptr = newOdome(port);
    LaserServer* pToLaserServer = new LaserServer(port);
    // odom_server = new LaserServer(port);

    //Subscribe to laser scan topic
    ros::Subscriber sub = n.subscribe <sensor_msgs::LaserScan> (laser_topic, 1, boost::bind(&scanCallback, _1, pToLaserServer) );
    //Open socket of choice
    
    ros::spin();

    return 0;

}


