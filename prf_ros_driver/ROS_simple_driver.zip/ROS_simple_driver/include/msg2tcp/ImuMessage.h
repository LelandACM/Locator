
//According to data struct 
struct __attribute__ ((packed)) ImuMessage
{
  double timestamp; //timestamp (UTC [sec]) of corr. scan
  uint32_t imu_number;
  uint64_t epoch;
  double orientation_qw;
  double orientation_qx;
  double orientation_qy;
  double orientation_qz;
  double omega_x;
  double omega_y;
  double omega_z;
  double a_x;
  double a_y;
  double a_z;
  bool orientation_set;
  bool linearacc_set;
};
