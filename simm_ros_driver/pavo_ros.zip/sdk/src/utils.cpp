#include "../include/utils.h"

pavo::SinuLookupTable*  pavo::SinuLookupTable::instance_ = NULL;
