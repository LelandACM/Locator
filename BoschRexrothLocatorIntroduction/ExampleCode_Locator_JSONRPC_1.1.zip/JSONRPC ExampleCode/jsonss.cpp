//#include <getopt.h>
#include <unistd.h>   //for sleep() at   void Bosch::startLocal()

#include <iostream>   //for licensingFeatureGetHostId
#include <fstream>    //for licensingFeatureGetHostId
//#include <assert.h>
//#include <netdb.h>
//#include <arpa/inet.h>
//#include <netinet/tcp.h>
//#include <vector>
//#include <string>
//#include <unistd.h>
//#include <memory.h>
//#include <sstream>

//#include <bitset>
#include "json.hpp"
#include <curl/curl.h>
using Json = nlohmann::json;
bool local_flag = false;
std::string hostId;

/* ******************************* libcurl, post json info.********************************** */
class HttpClient {
public:
  HttpClient();
  ~HttpClient();

public:
  static size_t receive_data(void *contents, size_t size, size_t nmemb, void *stream);
  // http post
  static CURLcode HttpPost(const std::string & strUrl, std::string szJson,std::string & strResponse,int nTimeout);
};

CURLcode HttpClient::HttpPost(const std::string & strUrl, std::string szJson,std::string & strResponse,int nTimeout){
  CURLcode res;
  char szJsonData[10240]; // for licensingFeatureSet change from 1024 to 10240
  memset(szJsonData, 0, sizeof(szJsonData));
  strcpy(szJsonData, szJson.c_str());
  CURL* pCURL = curl_easy_init();
  struct curl_slist* headers = NULL;
  if (pCURL == NULL) {
    return CURLE_FAILED_INIT;
  }

  CURLcode ret;
  ret = curl_easy_setopt(pCURL, CURLOPT_URL, strUrl.c_str());
//    std::cout << ret << std::endl;

  ret = curl_easy_setopt(pCURL, CURLOPT_POST, 1L);
  headers = curl_slist_append(headers,"Expect:");
  headers = curl_slist_append(headers,"content-type:application/json");
  ret = curl_easy_setopt(pCURL, CURLOPT_HTTPHEADER, headers);
  ret = curl_easy_setopt(pCURL, CURLOPT_POSTFIELDS, szJsonData);
  //curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);
  ret = curl_easy_setopt(pCURL, CURLOPT_TIMEOUT, nTimeout);
  ret = curl_easy_setopt(pCURL, CURLOPT_WRITEFUNCTION, HttpClient::receive_data);
  ret = curl_easy_setopt(pCURL, CURLOPT_WRITEDATA, (void*)&strResponse);
  res = curl_easy_perform(pCURL);
  curl_easy_cleanup(pCURL);
  return res;
}

size_t HttpClient::receive_data(void *contents, size_t size, size_t nmemb, void *stream){
  std::string *str = (std::string*)stream;
  (*str).append((char*)contents, size*nmemb);
  return size * nmemb;
}

/* *****************************Struct********************************************** */
typedef struct {
  bool calid;
  int64_t time;
  double resolution;  //number, must be one of 1, 100, 1000, 1000000, or 1000000000
}Timestamp;

typedef struct{
  double      x;	        //absolute x coordinate in map frame
  double      y;	        //absolute y coordinate in map frame
  double      z;	        //z coordinate
  double      qw;	        //quaternion w (real) coordinate
  double      qx;	        //quaternion x coordinate
  double      qy;	        //quaternion y coordinate
  double      qz;	        //quaternion z coordinate
}Pose3D;

typedef struct{
  double      x;	        //absolute x coordinate in map frame
  double      y;	        //absolute y coordinate in map frame
  double      z;	        //z coordinate
  double      qw;	        //quaternion w (real) coordinate
  double      qx;	        //quaternion x coordinate
  double      qy;	        //quaternion y coordinate
  double      qz;	        //quaternion z coordinate
}Transform3D;

typedef struct {
  double x;
  double y;
  double a;
}Pose2D;

typedef struct {
  std::string contentEncoding;
  std::string contentMediaType;
  std::string content;
}Container;

/*  ************************************JSON RPC command******************************* */
class Bosch {
public:
  Bosch(std::string host_name, std::string username, std::string password);
  
  //8.2 Session Control  (Module: Session)
  //8.2.1 sessionLogin： Login to a product element
  bool sessionLogin(int port);

  //8.4 Software Licensing (Module: LicensingFeature)
  //8.4.2 licensingFeatureGetHostId：  Retrieves the hardware-specific host ID.
  bool licensingFeatureGetHostId();
  //8.4.3 licensingFeatureSet: Sends a software license to the product element.
  bool licensingFeatureSet(std::string base64bin);

  //8.5 System Configuration
  //8.5.1 configList
  bool configList();
  //8.5.2 configSet : Sets all configurable parameters to the given values.
  bool configSet_string(std::string key,std::string value);
  bool configSet_num(std::string key, double value);
  bool configSet_bool(std::string key, bool value);
  //TODO 将输入int 改为list，保证多条线的输入
  bool configSet_array(std::string key, std::vector<int> line_data);

  //9.1 Recording (Module: ClientRecording) .
  //9.1.3 clientRecordingStartVisualRecording
  bool clientRecordingStartVisualRecording(std::string recordingName);   
  //9.1.4 clientRecordingStopVisualRecording
  bool clientRecordingStopVisualRecording();


  //9.3 Client Localization (Module: ClientLocalization)
  //9.3.1&9.3.2 clientLocalizationStart & Stop
  bool localSwitch(bool flag);
  //9.3.3 clientLocalizationSetSeed
  bool clientSetSeed(Pose2D pose);
  
  //9.6.1 & 9.6.2 MaskingStart/Stop :Requests to enter/leave the control mode MASK
  bool clientLaserMaskingStart();
  bool clientLaserMaskingStop();

  //9.6.3 clientLaserMaskingGetScan : Retrieves the next laser scan available to the Localization Client.
  bool clientLaserMaskingGetScan();

  //9.7 User Account Management (Module: ClientUser)
  //9.7.4 clientUserChangePassword： Changes a user’s password stored in the Localization Client.
  bool clientUserChangePassword();
  

  //11.1 Support Report(Module: SupportReport)
  //11.1.1 supportReportCreate: Creates a new support report that documents the current system state.
  bool supportReportCreate();


private:
  std::string username_;
  std::string password_;
  std::string host_name_;
  std::string session_id_;
};

Bosch::Bosch(std::string host_name, std::string username, std::string password) {
  host_name_ = host_name;
  username_ = username;
  password_ =password;
}

// 8.2.1 sessionLogin
bool Bosch::sessionLogin(int port) {
  std::cout<<"Do sessionLogin. \n"<<std::endl;
  //std::cout<<"    Different Module has different Session_ID";
  std::string port_str = std::to_string(port);
  //check if port is correct
  switch(port){
    case 8080:
      std::cout<< "   Port is 8080 and can operate Chapter 8 Shared RPC Method & Chapter 9 JSON RPC Localization Client Support "<<"\n"<<std::endl;
    break;
    case 8082:
      std::cout<< "   Port is 8082 and can operate Chapter 8 Shared RPC Method & Chapter 10 JSON RPC Map Server "<<"\n"<<std::endl;
    break;
    case 8084:
      std::cout<< "   Port is 8084 and can operate Chapter 11 JSON RPC Localization Client Support "<<"\n"<<std::endl;
    break;
    case 8086:
      std::cout<< "   Port is 8086 and can operate Chapter 12 JSON RPC Map Server "<<"\n"<<std::endl;
    break;
  }
  //set json info 
  Json timeout;
  timeout["valid"] = false;
  timeout["time"] = 86400;
  timeout["resolution"] = 1;
  Json request;
  request["id"] = 1;
  request["jsonrpc"] = "2.0";
  request["method"] = "sessionLogin";
  request["params"]["query"]["timeout"] = timeout;
  request["params"]["query"]["userName"] = username_;
  request["params"]["query"]["password"] = password_;
  
  
  // post json info
  std::string str_url = "http://" + host_name_ + ":" + port_str;
  std::string str_response;
  HttpClient::HttpPost(str_url, request.dump(), str_response, 300);
  //std::cout << "session login response: \n" << str_response << std::endl;
  
  //get error or necessary info
  Json json_response;
  try {
    json_response = Json::parse(str_response);
    int response_code = json_response["result"]["response"]["responseCode"];
    if (response_code == 0) {
      session_id_ = json_response["result"]["response"]["sessionId"];
      std::cout<<"    sessionLogin Success. \n"<<std::endl;
      std::cout<<"    SessionId is "<< session_id_<<"\n"<<std::endl;
      return true;
    } 
    else {
      return false;
    }
  } 
  catch (const std::exception &e) {
    std::cout << "Failed to parse JSON data: " << e.what() << std::endl;
    return false;
  }

}

// 8.4.2 licensingFeatureGetHostId
bool Bosch::licensingFeatureGetHostId(){
  std::cout<<"Do licensingFeatureGetHostId \n" <<std::endl;

  //set json info
  Json request;
  request["id"] = 1;
  request["jsonrpc"] = "2.0";
  request["method"] = "licensingFeatureGetHostId";
  request["params"]["query"]["sessionId"] = session_id_;


  //post json info
  std::string str_url =  "http://" + host_name_ + ":8080";
  std::string str_response;
  HttpClient::HttpPost(str_url, request.dump(), str_response, 300);

  //get error or necessary info
  Json json_response;
  try {
    json_response = Json::parse(str_response);
    int response_code = json_response["result"]["response"]["responseCode"];
    if (response_code == 0) {
      hostId = json_response["result"]["response"]["hostId"];
      std::cout<<"    licensingFeatureGetHostId Success. \n"<<std::endl;
      std::cout<<"    hostId is "<< hostId<<"\n"<<std::endl;
      return true;
    } 
    else {
      std::cout<<"    licensingFeatureGetHostId Failed."<<std::endl;
      std::cout<<"    licensingFeatureGetHostId response: \n" << str_response << std::endl;
      return false;
    }
  } 
  catch (const std::exception &e) {
    std::cout << "Failed to parse JSON data: " << e.what() << std::endl;
    return false;
  }

}

//8.4.3 licensingFeatureSet
bool Bosch::licensingFeatureSet(std::string base64bin) {
  std::cout<<"Do licensingFeatureSet. \n"<<std::endl;
  
  //set json info 

  Json request;
  request["id"] = 1;
  request["jsonrpc"] = "2.0";
  request["method"] = "licensingFeatureSet";
  request["params"]["query"]["sessionId"] = session_id_;
  request["params"]["query"]["licenseKey"]["contentEncoding"] = "base64";
  request["params"]["query"]["licenseKey"]["contentMediaType"] = "application/LicenseFile";
  request["params"]["query"]["licenseKey"]["content"] = base64bin;
  //std::cout<<request.dump()<<std::endl;
  
  // post json info
  std::string str_url = "http://" + host_name_ + ":8080";
  std::string str_response;
  HttpClient::HttpPost(str_url, request.dump(), str_response, 300);
  
  //get error or necessary info
  Json json_response;
  try {
    json_response = Json::parse(str_response);
    int response_code = json_response["result"]["response"]["responseCode"];
    if (response_code == 0) {
      std::cout<<"    licensingFeatureSet Success. \n"<<std::endl;
      return true;
    } 
    else {
      std::cout<<"    licensingFeatureSet Failed."<<std::endl;
      std::cout<<"    licensingFeatureSet response: \n" << str_response << std::endl;

      return false;
    }
  } 
  catch (const std::exception &e) {
    std::cout << "Failed to parse JSON data: " << e.what() << std::endl;
    return false;
  }

}

// base 64 encode for 8.4.3
const char* base64_chars[2] = {
             "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
             "abcdefghijklmnopqrstuvwxyz"
             "0123456789"
             "+/",

             "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
             "abcdefghijklmnopqrstuvwxyz"
             "0123456789"
             "-_"};

// base 64 encode for 8.4.3
std::string base64_encode(unsigned char const* bytes_to_encode, size_t in_len, bool url) {

    size_t len_encoded = (in_len +2) / 3 * 4;

    unsigned char trailing_char = url ? '.' : '=';

 //
 // Choose set of base64 characters. They differ
 // for the last two positions, depending on the url
 // parameter.
 // A bool (as is the parameter url) is guaranteed
 // to evaluate to either 0 or 1 in C++ therfore,
 // the correct character set is chosen by subscripting
 // base64_chars with url.
 //
    const char* base64_chars_ = base64_chars[url];

    std::string ret;
    ret.reserve(len_encoded);

    unsigned int pos = 0;

    while (pos < in_len) {
        ret.push_back(base64_chars_[(bytes_to_encode[pos + 0] & 0xfc) >> 2]);

        if (pos+1 < in_len) {
           ret.push_back(base64_chars_[((bytes_to_encode[pos + 0] & 0x03) << 4) + ((bytes_to_encode[pos + 1] & 0xf0) >> 4)]);

           if (pos+2 < in_len) {
              ret.push_back(base64_chars_[((bytes_to_encode[pos + 1] & 0x0f) << 2) + ((bytes_to_encode[pos + 2] & 0xc0) >> 6)]);
              ret.push_back(base64_chars_[  bytes_to_encode[pos + 2] & 0x3f]);
           }
           else {
              ret.push_back(base64_chars_[(bytes_to_encode[pos + 1] & 0x0f) << 2]);
              ret.push_back(trailing_char);
           }
        }
        else {

            ret.push_back(base64_chars_[(bytes_to_encode[pos + 0] & 0x03) << 4]);
            ret.push_back(trailing_char);
            ret.push_back(trailing_char);
        }

        pos += 3;
    }


    return ret;
}

//8.5.1 configList
bool Bosch::configList() {
  std::cout<<"Do configList. \n"<<std::endl;
  
  //set json info 
  Json request;
  request["id"] = 1;
  request["jsonrpc"] = "2.0";
  request["method"] = "configList";
  request["params"]["query"]["sessionId"] = session_id_;

  // post json info
  std::string str_url = "http://" + host_name_ + ":8080";
  std::string str_response;
  HttpClient::HttpPost(str_url, request.dump(), str_response, 300);
  
  // print  response info
  //std::cout << "configlist response: \n" << str_response << std::endl;
  
  //get error or necessary info
  Json json_response;
  try {
    json_response = Json::parse(str_response);

    // output config data
    auto key_value = json_response["result"]["response"]["configEntries"];
    std::cout<<"    Config info from Locator. (Related information on page 44/129 at APIDpcument 1.1 )\n"<<std::endl; 
    for(int i=0; i<key_value.size(); i = i+1){
      std::cout<<"    "<<key_value[i]<<std::endl; 
    }
    //std::cout<<typeid(key_value).name()<<std::endl;
    //cout particular key or value if necessary
    /*
    std::cout<<key_value[1]["key"]<<std::endl;
    std::cout<<key_value[1]["value"]<<std::endl;
    std::cout<<typeid(key_value).name()<<std::endl;
    */

   int response_code = json_response["result"]["response"]["responseCode"];
    if (response_code == 0) {
      std::cout<<"\n    configlist Success. \n"<<std::endl;
      return true;
    } 
    else {
      std::cout<<"    configList Failed."<<std::endl;
      std::cout<<"    configList response: \n" << str_response << std::endl;

      return false;
    } 
  } 
  catch (const std::exception &e) {
    std::cout << "Failed to parse JSON data: " << e.what() << std::endl;
    return false;
  }

}

//8.5.2 configSet string
bool Bosch::configSet_string(std::string key,std::string value) {
  //Config Param info from Locator. (Related information on page 44/129 at APIDpcument 1.1)
  std::cout<<"Do configSet (Type == AsciiCharacterString || string || NetworkAddress ). \n"<<std::endl;
  
  //set json info 
  Json confparam_string;
  confparam_string["key"] = key;
  confparam_string["value"] = value;

  Json request;
  request["id"] = 1;
  request["jsonrpc"] = "2.0";
  request["method"] = "configSet";
  request["params"]["query"]["sessionId"] = session_id_;
  request["params"]["query"]["configEntries"] = Json::array({confparam_string});

  // post json info
  std::string str_url = "http://" + host_name_ + ":8080";
  std::string str_response;
  std::string str_request;
  //std::cout<< request.dump()<<std::endl;
  HttpClient::HttpPost(str_url, request.dump(), str_response, 300);
  
  // print  response info
  //std::cout << "configlist response: \n" << str_response << std::endl;

  //get error or necessary info
  Json json_response;
  try {
    json_response = Json::parse(str_response);
    int response_code = json_response["result"]["response"]["responseCode"];
    if (response_code == 0) {
      std::cout<<"    configSet_string Success. Now config method is"<< confparam_string["key"]<<", config value is "<<confparam_string["value"]<<".\n" <<std::endl;
      return true;
    } 
    else {
      std::cout<<"    configSet_string Failed. "<<std::endl;
      std::cout<<"    configSet_string response: \n" << str_response << std::endl;
      return false;
    }
  } 
  catch (const std::exception &e) {
    std::cout << "Failed to parse JSON data: " << e.what() << std::endl;
    return false;
  }
}

//8.5.2 configSet number
bool Bosch::configSet_num(std::string key, double value) {
  //Config Param info from Locator. (Related information on page 44/129 at APIDpcument 1.1)
  std::cout<<"Do configSet (Type == IEEE754Double || NonnegativeInteger64 ). \n"<<std::endl;
  
  //set json info 
  Json confparam_num;
  confparam_num["key"] = "odometry_handler.laser_T_odo.x";
  confparam_num["value"] = -0.15;

  Json request;
  request["id"] = 1;
  request["jsonrpc"] = "2.0";
  request["method"] = "configSet";
  request["params"]["query"]["sessionId"] = session_id_;
  request["params"]["query"]["configEntries"] = Json::array({confparam_num});

  // post json info
  std::string str_url = "http://" + host_name_ + ":8080";
  std::string str_response;
  std::string str_request;
  //std::cout<< request.dump()<<std::endl;
  HttpClient::HttpPost(str_url, request.dump(), str_response, 300);
  
  // print  response info
  //std::cout << "configlist response: \n" << str_response << std::endl;

  //get error or necessary info
  Json json_response;
  try {
    json_response = Json::parse(str_response);
    int response_code = json_response["result"]["response"]["responseCode"];
    if (response_code == 0) {
      std::cout<<"    configSet_num Success. Now config method is"<< confparam_num["key"]<<", config value is "<<confparam_num["value"]<<".\n" <<std::endl;
      return true;
    } 
    else {
      std::cout<<"    configSet_num Failed. "<<std::endl;
      std::cout<<"    configSet_num response: \n" << str_response << std::endl;
      return false;
    }
  } 
  catch (const std::exception &e) {
    std::cout << "Failed to parse JSON data: " << e.what() << std::endl;
    return false;
  }
}

//8.5.2 configSet bool
bool Bosch::configSet_bool(std::string key, bool value) {
  //Config Param info from Locator. (Related information on page 44/129 at APIDpcument 1.1)
  std::cout<<"Do configSet (Type == bool ). \n"<<std::endl;
  
  //set json info 
  Json confparam_bool;
  confparam_bool["key"] = key;
  confparam_bool["value"] = value;

  Json request;
  request["id"] = 1;
  request["jsonrpc"] = "2.0";
  request["method"] = "configSet";
  request["params"]["query"]["sessionId"] = session_id_;
  request["params"]["query"]["configEntries"] = Json::array({confparam_bool});

  // post json info
  std::string str_url = "http://" + host_name_ + ":8080";
  std::string str_response;
  std::string str_request;
  //std::cout<< request.dump()<<std::endl;
  HttpClient::HttpPost(str_url, request.dump(), str_response, 300);
  
  // print  response info
  //std::cout << "configlist response: \n" << str_response << std::endl;

  //get error or necessary info
  Json json_response;
  try {
    json_response = Json::parse(str_response);
    int response_code = json_response["result"]["response"]["responseCode"];
    if (response_code == 0) {
      std::cout<<"    configSet_bool Success. Now config method is"<< confparam_bool["key"]<<", config value is "<<confparam_bool["value"]<<".\n" <<std::endl;
      return true;
    } 
    else {
      std::cout<<"    configSet_bool (bool) Failed. "<<std::endl;
      std::cout<<"    configSet_bool response: \n" << str_response << std::endl;
      return false;
    }
  } 
  catch (const std::exception &e) {
    std::cout << "Failed to parse JSON data: " << e.what() << std::endl;
    return false;
  }
}

//8.5.2 configSet array
bool Bosch::configSet_array(std::string key, std::vector<int> line_data) {
  //Config Param info from Locator. (Related information on page 44/129 at APIDpcument 1.1)
  std::cout<<"Do configSet (Type == arrya of IEEE754Double ). \n"<<std::endl;
  
  //set json info 
  auto range_line = Json::array();
  auto length =line_data.size();

  for(int i=0;i<length;i=i+1){
    int val = line_data[i];
    range_line.push_back(val);
  }; 

  Json confparam_array;
  confparam_array["key"] = key;
  confparam_array["value"] = range_line ;
  Json request;
  request["id"] = 1;
  request["jsonrpc"] = "2.0";
  request["method"] = "configSet";
  request["params"]["query"]["sessionId"] = session_id_;
  request["params"]["query"]["configEntries"] = Json::array({confparam_array});

  // post json info
  std::string str_url = "http://" + host_name_ + ":8080";
  std::string str_response;
  std::string str_request;
  //std::cout<< request.dump()<<std::endl;
  HttpClient::HttpPost(str_url, request.dump(), str_response, 300);
  
  // print  response info
  //std::cout << "configlist response: \n" << str_response << std::endl;

  //get error or necessary info
  Json json_response;
  try {
    json_response = Json::parse(str_response);
    int response_code = json_response["result"]["response"]["responseCode"];
    if (response_code == 0) {
      std::cout<<"    configSet_array Success. Now config method is"<< confparam_array["key"]<<", config value is "<<confparam_array["value"]<<".\n" <<std::endl;
      return true;
    } 
    else {
      std::cout<<"    configSet_array (array) Failed. "<<std::endl;
      std::cout<<"    configSet_array response: \n" << str_response << std::endl;
      return false;
    }
  } 
  catch (const std::exception &e) {
    std::cout << "Failed to parse JSON data: " << e.what() << std::endl;
    return false;
  }
}

//9.1.3 clientRecordingStartVisualRecording
bool Bosch::clientRecordingStartVisualRecording(std::string  recordingName) {
  std::cout<<"Do clientRecordingStartVisualRecording. \n"<<std::endl;
  
  //set json info 
 
  Json request;
  request["id"] = 1;
  request["jsonrpc"] = "2.0";
  request["method"] = "clientRecordingStartVisualRecording";
  request["params"]["query"]["sessionId"] = session_id_;
  request["params"]["query"]["recordingName"] = recordingName;
  
  
  // post json info
  std::string str_url = "http://" + host_name_ + ":8080";
  std::string str_response;
  HttpClient::HttpPost(str_url, request.dump(), str_response, 300);

  
  //get error or necessary info
  Json json_response;
  try {
    json_response = Json::parse(str_response);
    int response_code = json_response["result"]["response"]["responseCode"];
    if (response_code == 0) {
      std::cout<<"    clientRecordingStartVisualRecording Success. \n"<<std::endl;
      return true;
    } 
    else if(response_code ==13){
      std::cout<<"    clientRecordingStartVisualRecording Failed (Code == 13). \n"<<std::endl;
      std::cout << "   A required sensor was not available. Connect Lidar first. \n"<<"   " << str_response << std::endl;
      return false;
    }else if(response_code ==10){
      std::cout<<"    clientRecordingStartVisualRecording Failed (Code == 10). \n"<<std::endl;
      std::cout << "    Tried to create an entity that already exists. Change the name of recordingName. \n"<<"    " << str_response<<"\n" << std::endl;
    }
    else{
      
      std::cout<<"    clientRecordingStartVisualRecording Failed. \n"<<std::endl;
      std::cout << "   clientRecordingStartVisualRecording response: \n" <<"   "<< str_response <<"\n"<< std::endl;
      return false;

    }
  } 
  catch (const std::exception &e) {
    std::cout << "Failed to parse JSON data: " << e.what() << std::endl;
    return false;
  }

}

//9.1.4 clientRecordingStopVisualRecording
bool Bosch::clientRecordingStopVisualRecording(){
  std::cout<<"Do clientRecordingStopVisualRecording. \n"<<std::endl;
  
  //set json info 
 
  Json request;
  request["id"] = 1;
  request["jsonrpc"] = "2.0";
  request["method"] = "clientRecordingStopVisualRecording";
  request["params"]["query"]["sessionId"] = session_id_;

  
  // post json info
  std::string str_url = "http://" + host_name_ + ":8080";
  std::string str_response;
  HttpClient::HttpPost(str_url, request.dump(), str_response, 300);

  
  //get error or necessary info
  Json json_response;
  try {
    json_response = Json::parse(str_response);
    int response_code = json_response["result"]["response"]["responseCode"];
    if (response_code == 0) {
      std::cout<<"    clientRecordingStartVisualRecording Success. \n"<<std::endl;
      return true;
    } 
    else if(response_code ==7){
      std::cout<<"    clientRecordingStopisualRecording Failed (Code == 7). \n"<<std::endl;
      std::cout << "    The current system state does not allow the operation to complete. Start Recording first. \n"<<"     " << str_response << std::endl;
      return false;
    }
    else{
      std::cout<<"     clientRecordingStopVisualRecording Failed. \n"<<std::endl;
      std::cout << "    clientRecordingStopVisualRecording response: \n"<<"    " << str_response << std::endl;
      return false;

    }
  } 
  catch (const std::exception &e) {
    std::cout << "Failed to parse JSON data: " << e.what() << std::endl;
    return false;
  }

}

//9.3.1 &9.3.2 clientLocalizationStart & Stop
bool Bosch::localSwitch(bool local_flag) {
  std::cout<<"Do localSwitch. \n"<<std::endl;

  // set json info
  Json request;
  request["id"] = 1;
  request["jsonrpc"] = "2.0";
  if (local_flag == true) {
    request["method"] = "clientLocalizationStop";
  } else {
    request["method"] = "clientLocalizationStart";
   }
  request["params"]["query"]["sessionId"] = session_id_;

  //post JSON info
  std::string str_url = "http://" + host_name_ + ":8080";
  std::string str_response;
  HttpClient::HttpPost(str_url, request.dump(), str_response, 300);
  //std::cout << "switch localization response: " << str_response << std::endl;
  

  //get error or necessary info
  Json json;
  try {
    json = Json::parse(str_response);
    int response_code = json["result"]["response"]["responseCode"];
    if (response_code == 0) {
      std::cout<<"    localSwitch Success. Now "<< request["method"]<<"\n" <<std::endl;
      if (request["method"] =="clientLocalizationStop"){
        local_flag = false;}else{
          local_flag = true;
        } 
      return true;
    } else {
      std::cout<<"    localSwitch Failed. "<<std::endl;
      std::cout<<"    post localSwitch method is "<<request["method"]<<std::endl;
      std::cout<<"    localSwitch: " << str_response << std::endl;
      return false;
    }
  } catch (const std::exception &e) {
    std::cout << "Failed to parse JSON data: " << e.what() << std::endl;
    return false;
  }
}

//9.3.3 clientLocalizationSetSeed
bool Bosch::clientSetSeed(Pose2D pose){
  std::cout<<"Do clientLocalizationSetSeed. \n"<<std::endl;
  
  // set json info
  Json request;
  request["id"] = 1;
  request["jsonrpc"] = "2.0";
  request["method"] = "clientLocalizationSetSeed";
  request["params"]["query"]["sessionId"] = session_id_;
  request["params"]["query"]["enforceSeed"] = true;
  request["params"]["query"]["seedPose"]["x"] = pose.x;
  request["params"]["query"]["seedPose"]["y"] = pose.y;
  request["params"]["query"]["seedPose"]["a"] = pose.a;
  
  //post JSON info 
  std::string str_url = "http://" + host_name_ + ":8080";
  std::string str_response;
  HttpClient::HttpPost(str_url, request.dump(), str_response, 300);
  //std::cout << "SetSeed response: " << str_response << std::endl;


  //get error or necessary info
  Json json_response;
  try {
    json_response = Json::parse(str_response);
    int response_code = json_response["result"]["response"]["responseCode"];
    if (response_code == 0) {
      std::cout<<"    clientLocalizationSetSeed Success.\n"<<std::endl;
      return true;
    } 
    else {
      std::cout<<"    clientLocalizationSetSeed Failed. "<<std::endl;
      std::cout<<"    clientLocalizationSetSeed response: \n" << str_response << std::endl;
      return false;
    }
  } 
  catch (const std::exception &e) {
    std::cout << "Failed to parse JSON data: " << e.what() << std::endl;
    return false;
  } 

}

//9.6.1 clientLaserMaskingStart
bool Bosch::clientLaserMaskingStart() {
  std::cout<<"Do clientLaserMaskingStart. \n"<<std::endl;

  // set json info
  Json request;
  request["id"] = 1;
  request["jsonrpc"] = "2.0";
  request["method"] = "clientLaserMaskingStart";
  request["params"]["query"]["sessionId"] = session_id_;

  //post JSON info
  std::string str_url = "http://" + host_name_ + ":8080";
  std::string str_response;
  HttpClient::HttpPost(str_url, request.dump(), str_response, 300);
  //std::cout << "clientLaserMaskingStart response: " << str_response << std::endl;
  

  //get error or necessary info
  Json json_response;
  try {
    json_response = Json::parse(str_response);
    int response_code = json_response["result"]["response"]["responseCode"];
    if (response_code == 0) {
      std::cout<<"    clientLaserMaskingStart Success. \n"<<std::endl;
      return true;
    } 
    else  if(response_code ==2){
      std::cout<<"    clientLaserMaskingStart Failed! "<<std::endl;
      std::cout<<"    clientLaserMaskingStart response: \n" << str_response << std::endl;
      std::cout<<"    connect Lidar first, after recieve the laser scan then you can start MAKING. \n"<<std::endl;
      return false;
    }else
    {
      return false;
    }
    
  } 
  catch (const std::exception &e) {
    std::cout <<"Failed to parse JSON data: " << e.what() << std::endl;
    return false;
  }

}

//9.6.2 clientLaserMaskingStop
bool Bosch::clientLaserMaskingStop() {
  std::cout<<"Do clientLaserMaskingStop. \n"<<std::endl;

  // set json info
  Json request;
  request["id"] = 1;
  request["jsonrpc"] = "2.0";
  request["method"] = "clientLaserMaskingStop";
  request["params"]["query"]["sessionId"] = session_id_;

  //post JSON info
  std::string str_url = "http://" + host_name_ + ":8080";
  std::string str_response;
  HttpClient::HttpPost(str_url, request.dump(), str_response, 300);
  //std::cout << "clientLaserMaskingStart response: " << str_response << std::endl;
  

  //get error or necessary info
  Json json_response;
  try {
    json_response = Json::parse(str_response);
    int response_code = json_response["result"]["response"]["responseCode"];
    if (response_code == 0) {
      std::cout<<"    clientLaserMaskingStop Success. \n"<<std::endl;
      return true;
    } 
    else {
      std::cout<<"    clientLaserMaskingStop Failed. "<<std::endl;
      std::cout<<"    clientLaserMaskingStop response: \n" << str_response << std::endl;
      return false;
    }
  } 
  catch (const std::exception &e) {
    std::cout << "Failed to parse JSON data: " << e.what() << std::endl;
    return false;
  }

}

//9.6.3 clientLaserMaskingGetScan 
bool Bosch::clientLaserMaskingGetScan() {
  std::cout<<"Do clientLaserMaskingGetScan. \n"<<std::endl;

  // set json info
  Json request;
  request["id"] = 1;
  request["jsonrpc"] = "2.0";
  request["method"] = "clientLaserMaskingGetScan";
  request["params"]["query"]["sessionId"] = session_id_;

  //post JSON info
  std::string str_url = "http://" + host_name_ + ":8080";
  std::string str_response;
  HttpClient::HttpPost(str_url, request.dump(), str_response, 300);
  //std::cout << "clientLaserMaskingGetScan response: " << str_response << std::endl;
  

  //get error or necessary info
  Json json_response;
  try {
    json_response = Json::parse(str_response);

    
    int response_code = json_response["result"]["response"]["responseCode"];
    if (response_code == 0) {
      //cout the inportant data
      std::cout<<"    Some Important info about this Masking Scan"<<std::endl;
      std::cout<<"    maxRange is "<< json_response["result"]["response"]["maxRange"] <<std::endl;
      std::cout<<"    numBeams is "<< json_response["result"]["response"]["numBeams"] <<std::endl;
      std::cout<<"    Scan time is "<< json_response["result"]["response"]["timeStart"]["time"] <<"\n"<<std::endl;
      std::cout<<"    clientLaserMaskingGetScan Success. \n"<<std::endl;
      return true;
    } else if(response_code == 7){
      std::cout<<"    clientLaserMaskingGetScan Failed! \n "<<std::endl;
      std::cout<<"    clientLaserMaskingGetScan response: " << str_response << "\n"<<std::endl;
      std::cout<<"    Possible Reason: Lack of step 1:Connect Lidar or 2:start MAKING,after that operate step3: GetScan Masking \n"<<std::endl;
      return false;
    }else{
      std::cout<<"    clientLaserMaskingGetScan Failed! \n"<<std::endl;
      std::cout<<"    clientLaserMaskingGetScan response: " << str_response << std::endl;
      return false;
    }
  } 
  catch (const std::exception &e) {
    std::cout << "Failed to parse JSON data: " << e.what() << std::endl;
    return false;
  }

}

//9.7.4 clientUserChangePassword
bool Bosch::clientUserChangePassword(){
  std::cout<<"Do clientUserChangePassword. \n"<<std::endl;
  
  // set json info
  Json request;
  request["id"] = 1;
  request["jsonrpc"] = "2.0";
  request["method"] = "clientUserChangePassword";
  request["params"]["query"]["sessionId"] = session_id_;
  request["params"]["query"]["userName"]  = username_;
  request["params"]["query"]["newUserPassword"]  = "123456";

  //post JSON info
  std::string str_url = "http://" + host_name_ + ":8080";
  std::string str_response;
  HttpClient::HttpPost(str_url, request.dump(), str_response, 300);
  //std::cout << "changepassword response: \n " << str_response << std::endl;

  //get error or necessary info
  Json json;
  try {
    json = Json::parse(str_response);
    int response_code = json["result"]["response"]["responseCode"];
    if (response_code == 0) {
      std::cout<<"    clientUserChangePassword Success.\n"<<std::endl;
      std::cout<<"   newUserPassword is "<< request["params"]["query"]["newUserPassword"] <<"\n"<<std::endl;
      return true;
    } else {
      std::cout<<"    clientUserChangePassword Failed! \n"<<std::endl;
      std::cout<<"    clientUserChangePassword response: " << str_response << std::endl;
      return false;
    }
  } catch (const std::exception &e) {
    std::cout << "Failed to parse JSON data: " << e.what() << std::endl;
    return false;
  }
 
}

// 11.1.1 supportReportCreate
bool Bosch::supportReportCreate() {
  std::cout<<"Do supportReportCreate. \n"<<std::endl;
  
  //set json info 
  Json request;
  request["id"] = 1;
  request["jsonrpc"] = "2.0";
  request["method"] = "supportReportCreate";
  request["params"]["query"]["sessionId"] = session_id_;
  
  // post json info
  std::string str_url = "http://" + host_name_ + ":8084";
  std::string str_response;
  HttpClient::HttpPost(str_url, request.dump(), str_response, 300);
  
  //get error or necessary info
  Json json_response;
  try {
    json_response = Json::parse(str_response);
    int response_code = json_response["result"]["response"]["responseCode"];
    if (response_code == 0) {
      std::cout<<"    supportReportCreate Success. \n"<<std::endl;
      std::cout<<"    SupportReportName is "<< json_response["result"]["response"]["reportName"]<<"\n"<<std::endl;
      return true;
    } 
    else {
      return false;
    }
  } 
  catch (const std::exception &e) {
    std::cout << "Failed to parse JSON data: " << e.what() << std::endl;
    return false;
  }

}


int main(int argc, char **argv){
    // init
    Bosch bosch_localization("127.0.0.1", "admin", "123456");
    
    //8.2.1 sessionLogin
    bosch_localization.sessionLogin(8080); 

    //8.4.2 licensingFeatureGetHostId
    //bosch_localization.licensingFeatureGetHostId();

    //8.4.3 licensingFeatureSet
    /*
    std::ifstream is ("testfile.bin", std::ifstream::binary);
    // get length of file:
    is.seekg (0, is.end);
    unsigned int length = is.tellg();
    is.seekg (0, is.beg);
    char *buffer = new char [length];
    is.read (buffer,length);
    const std::string myString(buffer, length);
    std::string binfileencode =  base64_encode(reinterpret_cast<const unsigned char*>(myString.c_str()), myString.length(),false);
    bosch_localization.licensingFeatureSet(binfileencode);
    */

    //8.5.1 configList
    //bosch_localization.configList();

    //8.5.2 configSet
    //bosch_localization.configSet_string("licensing.method","WIBUDONGLE");
    //bosch_localization.configSet_bool("config_laser.shall_mirror_scans",true);
    //bosch_localization.configSet_num("odometry_handler.laser_T_odo.x", -0.85);
    // line_data= {line1x_1,line1y_1,line1x_2,line1y_2,line2x_1,line2y_1,line2x_2,line2y_2} etc.
    std::vector<int> line_data = {3,4,5,6,1,1,2,5};
    bosch_localization.configSet_array("config_laser.mask.min_range_line_data",line_data);

    //9.1.3 clientRecordingStartVisualRecording
    //bosch_localization.clientRecordingStartVisualRecording("testfileName");
    //9.1.4 clientRecordingStopVisualRecording
    //bosch_localization.clientRecordingStopVisualRecording();


    //9.3.1 & 9.3.2 clientLocalizationStart & Stop
    //如果 flag是 true 说明locate打开，那么要要关掉locate功能并返回false
    //bosch_localization.localSwitch(local_flag);
    /*
    sleep(2);
    local_flag = bosch_localization.localSwitch(local_flag);
    sleep(2);
    local_flag = bosch_localization.localSwitch(local_flag);
    sleep(2);
    local_flag = bosch_localization.localSwitch(local_flag);
    */

    //9.3.3 clientLocalizationSetSeed
    
    //first define Pose2D
    /*
    Pose2D posetest;
    posetest.x = 15;
    posetest.y = 200;
    posetest.a = 0.2;
    bosch_localization.clientSetSeed(posetest);
    */

    //9.6.1 clientLaserMaskingStart
    
    //bosch_localization.clientLaserMaskingStart();
    //bosch_localization.clientLaserMaskingGetScan();
    //sleep(1);
    //bosch_localization.clientLaserMaskingStop();
    //9.7.4 clientUserChangePassword
    //bosch_localization.clientUserChangePassword();


    //11.1.1 supportReportCreate
    bosch_localization.sessionLogin(8084);
    bosch_localization.supportReportCreate();
    //bosch_localization.licensingFeatureGetHostId();
    return 0;
}