import csv
import matplotlib.pyplot as plt
import numpy as np
import os
import shutil
import time

now = int(round(time.time()*1000))
now02 = time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(now/1000)).replace(" ","_")
txtpath = os.getcwd()+"/port_9005_output.txt"
os.mkdir(os.getcwd()+"/port_9007output_"+now02)
filepath = os.getcwd()+"/port_9007output_"+now02

# shanchu le zhege txt kehaixing
# shutil.move(txtpath,filepath)
# txtpath = os.getcwd()+"/port_9007output"+now02+"/output.txt"

mapnum = 0
plotcolor = ['black','rosybrown','orange','olive','green','cyan','slategray','pink','darkviolet']

'''读取txt，将时间戳，定位状态，位置x, 位置y储存到四个list中'''
with open(txtpath) as out:
    timestamp = []
    pose_x = []
    pose_y = []
    pose_x_old = []
    pose_y_old = []
    pose_x_new = []
    pose_y_new = []

    for line in out:
        if "time:" in line:
            timestamp.append(line.split(":")[1])
            mapnum = mapnum+1
            # 新建list，用来存储xy数据，backup 是用来比较数据的，不做更改
            exec("pose_x_" + str(mapnum) + "=[]")
            exec("pose_x_backup_" + str(mapnum) + "=[]")
            exec("pose_y_" + str(mapnum) + "=[]")
            exec("pose_y_backup_" + str(mapnum) + "=[]")
        elif "," in line:
            # 存储xy数据
            exec("pose_x_"+str(mapnum) +".append(float(line.split(\",\")[0]))")
            exec("pose_x_backup_" + str(mapnum) + ".append(float(line.split(\",\")[0]))")
            exec("pose_y_" + str(mapnum) + ".append(float(line.split(\",\")[1]))")
            exec("pose_y_backup_" + str(mapnum) + ".append(float(line.split(\",\")[1]))")

    for i in range(1,mapnum):
        #先输出的点云图的点云数量（list）长度小于后输出的点云list长度
        #
        exec("pose_x_old" + "=" + "pose_x_backup_" + str(i))
        exec("pose_y_old" + "=" + "pose_y_backup_" + str(i))
        exec("pose_x_new" + "=" + "pose_x_backup_" + str(i+1))
        exec("pose_y_new" + "=" + "pose_y_backup_" + str(i+1))
        for j in range(len(pose_y_old)-1):
            if pose_y_old[j]==pose_y_new[j] and pose_x_old[j]==pose_x_new[j]:
             exec("pose_x_" + str(i + 1) + "[j]=0")
             exec("pose_y_" + str(i + 1) + "[j]=0")


# 绘制每一次更新后整个map
for i in range(1,mapnum+1):

    exec("pose_x"+ "="+ "pose_x_"+str(i))
    exec("pose_y" + "=" + "pose_y_" + str(i))
    width_of_png = (max(pose_x) - min(pose_x))
    lenth_of_png = (max(pose_y) - min(pose_y))
    plt.figure(figsize=(width_of_png, lenth_of_png))
    for j in range(len(pose_x)-1):
        pass
    plt.plot(pose_x, pose_y,',',color ='r')

    plt.savefig(filepath +"/submap_" + str(i) + "_at_" + timestamp[i - 1].replace("\n","") + ".png")
    plt.close()


#绘制每一次更新后增加的点云map
for i in range(1,mapnum+1):

    exec("pose_x"+ "="+ "pose_x_backup_"+str(i))
    exec("pose_y" + "=" + "pose_y_backup_" + str(i))
    width_of_png = (max(pose_x) - min(pose_x))
    lenth_of_png = (max(pose_y) - min(pose_y))
    plt.figure(figsize=(width_of_png, lenth_of_png))
    for j in range(len(pose_x)-1):
        pass
    plt.plot(pose_x, pose_y,',',color ='r')
    plt.savefig(filepath+"/map_"+str(i)+"_at_"+timestamp[i-1].replace("\n","")+".png")
    plt.close()

wid_of_png = 0
lenth_of_png = 0
max_x = 0
min_x = 0
max_y = 0
min_y = 0

for i in range(1,mapnum+1):
    exec("pose_x"+ "="+ "pose_x_backup_"+str(i))
    exec("pose_y" + "=" + "pose_y_backup_" + str(i))

    max_x_of_submap =  max(pose_x)
    min_x_of_submap = min(pose_x)
    max_y_of_submap = max(pose_y)
    min_y_of_submap = min(pose_y)

    if max_x_of_submap > max_x:
        max_x = max_x_of_submap
    else:
        pass
    if min_x_of_submap < min_x:
        min_x = min_x_of_submap
    else:
        pass
    if max_y_of_submap > max_y:
        max_y = max_y_of_submap
    else:
        pass
    if min_y_of_submap < min_y:
        min_y = min_y_of_submap

width_of_png = max_x - min_x
lenth_of_png = max_y - min_y
plt.figure(figsize=(width_of_png, lenth_of_png))

for i in range(1,mapnum+1):
    exec("pose_x"+ "="+ "pose_x_backup_"+str(i))
    exec("pose_y" + "=" + "pose_y_backup_" + str(i))
    plt.plot(pose_x,pose_y,',',color = plotcolor[i%len(plotcolor)])
    plt.savefig(filepath+ "/totalmap.png")
