/*
 * File: TestClientLocalizationPose.cpp
 * Created On: 2019-03-13
 * Copyright © 2019 Bosch Rexroth AG
*/

/*
 * Parser for command line parameters
 */
#include <getopt.h>

/*
 * C++ Standard Library headers
 */
#include <iostream>
#include <fstream>
#include <string>
#include <assert.h>
#include <exception>
#include <signal.h>
#include <iomanip>
#include <vector>
#include <mutex>
#include <time.h>
#include <bitset>
std::mutex mtx;
using namespace std;
/*
 * MessageStructs and BinaryClient Objects
 */
#include "BinaryInterfaceDataStruct.h"
#include "BinaryInterfaceClient.h"

//global variant
vector<pair<float,float>> scan_points_position;   //vector for x & y
vector<vector<float>> scan_points_pose; // vector for  x & y & yaw

string getCurrentSystemTime()
{
    std::time_t secSinceEpoch = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now());    //Seconds since the Epoch
    struct tm* calendarTime = localtime(&secSinceEpoch);    
    char usrdefFormat[50] = { 0 };   
    strftime(usrdefFormat, 50, "%Y%m%d%H%M%S", calendarTime);    //格式：20191101135525
    return string(usrdefFormat);
}

// Port 9004
void BinaryInterface_control (const std::string &hostName,int portNum)
{   
    try
    {
        // Create the client. It will connect to the server while construction
        cout <<"Connect to Binary Interface 9004."<< endl;
        BinaryInterfaceClient client(hostName, portNum);

        // Create output file
        string outputtxt = "port_" +to_string(portNum) + "_output.txt";
        cout<< "Create ouput file: "<< outputtxt <<"\n"<<std::endl;
        ofstream ofresult(outputtxt);
        std::cout << "------------------- Bosch Rexroth LLS Binary Interface " << "---------------------" << std::endl;

        ClientControlModeDatagram controlmode;
        //PoseMessage poseMessage;
        int32_t rv = 0;
        while (rv >= 0)
        {
            //rv = client.read(&poseMessage, sizeof(poseMessage));
            uint32_t mode ;
            rv = client.read(&controlmode, sizeof(controlmode));
            bitset<32> mdoes_state = bitset<32>(controlmode.controlMode);
            ofresult << "Current system time :" <<  getCurrentSystemTime()<<endl; 
            cout << "Current system time :" <<  getCurrentSystemTime()<<endl; 
            ofresult <<"Mdoes_state :" << mdoes_state << endl;
            cout << "Mdoes_state :" << mdoes_state << endl;
        
            
            // MASK MODE
            if(mdoes_state[0]==1){
                ofresult << "MASK_MODE READY" << endl;
                cout << "MASK_MODE READY" << endl;
            }
            else if (mdoes_state[1]==1)
            {
                ofresult << "MASK_MODE RUN" << endl;
                cout << "MASK_MODE RUN" << endl;
            }
            else if (mdoes_state[2]==1)
            {
                ofresult << "MASK_MODE NOT_AVAILABLE" << endl;
                cout << "MASK_MODE NOT_AVAILABLE" << endl;
            }
            else if (mdoes_state[0]==0 & mdoes_state[1]==0 & mdoes_state[2]==0)
            {
                ofresult << "MASK_MODE INIT" << endl;
                cout << "MASK_MODE INIT" << endl;
            }

            // ALIGN MODE
            if(mdoes_state[3]==1){
                ofresult << "ALIGN_MODE READY" << endl;
                cout << "ALIGN_MODE READY" << endl;
            }
            else if (mdoes_state[4]==1)
            {
                ofresult << "ALIGN_MODE RUN" << endl;
                cout << "ALIGN_MODE RUN" << endl;
            }
            else if (mdoes_state[5]==1)
            {
                ofresult << "ALIGN_MODE NOT_AVAILABLE" << endl;
                cout << "ALIGN_MODE NOT_AVAILABLE" << endl;
            }
            else if (mdoes_state[3]==0 & mdoes_state[4]==0 & mdoes_state[5]==0)
            {
                ofresult << "ALIGN_MODE INIT" << endl;
                cout << "ALIGN_MODE INIT" << endl;
            }            
            
            // REC MODE
            if(mdoes_state[6]==1){
                ofresult << "REC_MODE READY" << endl;
                cout << "REC_MODE READY" << endl;
            }
            else if (mdoes_state[7]==1)
            {
                ofresult << "REC_MODE RUN" << endl;
                cout << "REC_MODE RUN" << endl;
            }
            else if (mdoes_state[8]==1)
            {
                ofresult << "REC_MODE NOT_AVAILABLE" << endl;
                cout << "REC_MODE NOT_AVAILABLE" << endl;
            }
            else if (mdoes_state[6]==0 & mdoes_state[7]==0 & mdoes_state[8]==0)
            {
                ofresult << "REC_MODE INIT" << endl;
                cout << "REC_MODE INIT" << endl;
            } 

            // LOC MODE
            if(mdoes_state[9]==1){
                ofresult << "LOC_MODE READY" << endl;
                cout << "LOC_MODE READY" << endl;
            }
            else if (mdoes_state[10]==1)
            {
                ofresult << "LOC_MODE RUN" << endl;
                cout << "LOC_MODE RUN" << endl;
            }
            else if (mdoes_state[11]==1)
            {
                ofresult << "LOC_MODE NOT_AVAILABLE" << endl;
                cout << "LOC_MODE NOT_AVAILABLE" << endl;
            }
            else if (mdoes_state[9]==0 & mdoes_state[10]==0 & mdoes_state[11]==0)
            {
                ofresult << "LOC_MODE INIT" << endl;
                cout << "LOC_MODE INIT" << endl;
            } 

            // MAP MODE
            if(mdoes_state[12]==1){
                ofresult << "MAP_MODE READY" << endl;
                cout << "MAP_MODE READY" << endl;
            }
            else if (mdoes_state[13]==1)
            {
                ofresult << "MAP_MODE RUN" << endl;
                cout << "MAP_MODE RUN" << endl;
            }
            else if (mdoes_state[14]==1)
            {
                ofresult << "MAP_MODE NOT_AVAILABLE" << endl;
                cout << "MAP_MODE NOT_AVAILABLE" << endl;
            }
            else if (mdoes_state[12]==0 & mdoes_state[13]==0 & mdoes_state[14]==0)
            {
                ofresult << "MAP_MODE INIT" << endl;
                cout << "MAP_MODE INIT" << endl;
            }

            // VISUALRECORDING MODE
            if(mdoes_state[15]==1){
                ofresult << "VISUALRECORDING_MODE READY" << endl;
                cout << "VISUALRECORDING_MODE READY" << endl;
            }
            else if (mdoes_state[16]==1)
            {
                ofresult << "VISUALRECORDING_MODE RUN" << endl;
                cout << "VISUALRECORDING_MODE RUN" << endl;
            }
            else if (mdoes_state[17]==1)
            {
                ofresult << "VISUALRECORDING_MODE NOT_AVAILABLE" << endl;
                cout << "VISUALRECORDING_MODE NOT_AVAILABLE" << endl;
            }
            else if (mdoes_state[15]==0 & mdoes_state[16]==0 & mdoes_state[17]==0)
            {
                ofresult << "VISUALRECORDING_MODE INIT" << endl;
                cout << "VISUALRECORDING_MODE INIT" << endl;
            }

            std::cout << "----------------------------------------" << std::endl;
            ofresult << "----------------------------------------" << std::endl;
        }

        std::cout << "Socket call __read__ returned with signal: Socket closed." << std::endl;
        ofresult << flush;
        ofresult.close();
    }
    catch(std::exception& ex)
    {
        std::cerr << "Error during TCP Receiving test: " << std::string(ex.what()) << std::endl;
    }

}


// 9006 9008
void BinaryInterface_map_rec_visu (const std::string &hostName,int portNum)
{
    
    try
    {
        cout <<"Connect to Binary Interface "<<  portNum<<"."<< endl;
        BinaryInterfaceClient client(hostName, portNum);
        string outputtxt = "port_" +to_string(portNum) + "_output.txt";
        cout<< "Create ouput file: "<< outputtxt <<std::endl;
        ofstream ofresult(outputtxt);
        std::cout << "------------------- Bosch Rexroth LLS Binary Interface " << "---------------------" << std::endl;

        Client_Map_Recording_VisualizationDatagram mapvisudata;
        int32_t rv = 0;
        while (rv >= 0)
        {   
            rv = client.read(&mapvisudata, sizeof(mapvisudata));
            //std::cout<< "rv valus"<<rv<<std::endl;
            if (rv > 0)
            {   time_t diagnos_info_time = mapvisudata.timestamp;
                //std::cout<<"Time（UTC/GMT+08:00）="<<ctime(&diagnos_info_time);
                cout << "timestamp  = "<<setprecision(13) << mapvisudata.timestamp  << endl;
                ofresult << "timestamp:" <<setprecision(13) << mapvisudata.timestamp  << endl;
                cout << "visualizationId = " << mapvisudata.visualizationld << endl;
                cout << "status  = " << mapvisudata.status  << endl;
                cout << "poseX  = " << mapvisudata.poseX  << endl;
                ofresult << "poseX:" << mapvisudata.poseX  << endl;
                cout << "poseY = " << mapvisudata.poseY  << endl;
                ofresult << "poseY:" << mapvisudata.poseY  << endl;
                cout << "poseYaw   = " << mapvisudata.poseYaw         << endl;
                cout << "disToLaseC = " << mapvisudata.distanceToLastLC       << endl;
                cout << "delay = " << mapvisudata.delay         << endl;
                cout << "progress  = " << mapvisudata.progress       << endl;
                
                //read the length of scan
                uint32_t scan_length;
                client.read(&scan_length,4);
                cout<<"scan->length = "<< scan_length << endl;
                scan_points_position.clear(); //clear the last scan
            
                for(int i = 0;i <scan_length;i++)
                {
                    float x,y;
                    client.read(&x,4);
                    client.read(&y,4);
                    scan_points_position.push_back(make_pair(x,y)); 
                }
       
                // output the scan element
                /*
                for(int i = 0; i < scan_points_position.size(); i++){
                     cout << scan_points_position[i].first << ", " << scan_points_position[i].second << endl;
                    }
                */

                //read the length of pathpPoses
                uint32_t pathPoses_length;
                client.read(&pathPoses_length,4);
                cout<<"pathPoses->length = "<< pathPoses_length << endl;
                scan_points_pose.clear();
                for(int i = 0;i <pathPoses_length;i++)
                {
                    
                    float x,y,yaw;
                    client.read(&x,4);
                    client.read(&y,4);
                    client.read(&yaw,4);
                    scan_points_pose.push_back({x,y,yaw});
                }

                // output the pose element

                /*
                for(int i =0 ; i<pathPoses_length; i++){
                    cout << scan_points_pose[i][2]<<endl; //yaw
                }
                */

                //read the length of pathTypes
                uint32_t pathTypes_length;
                client.read(&pathTypes_length,4);
                cout<<"pathTypes->length = "<< pathTypes_length << endl;
                for(int i = 0;i <pathTypes_length;i++)
                {
                    float x;
                    client.read(&x,4); 
                }
                std::cout << "----------------------------------------" << std::endl;
            }

            else if  (rv == 0)
            {
                std::cout << "Socket call __read__ returned zero." << std::endl;
            }
        }

    std::cout << "Socket call returned with signal: Socket closed." << std::endl;
    
    ofresult << flush;
    ofresult.close();
    }
    catch(std::exception& ex)
    {
        std::cerr << "Error during TCP Receiving test: " << std::string(ex.what()) << std::endl;
    }
    
}


// 9005 9007 9009
void BinaryInterface_map_rec_loc_map (const std::string &hostName,int portNum)
{   
    try
    {
        cout <<"Connect to Binary Interface "<<  portNum<<"."<< endl;
        BinaryInterfaceClient client(hostName, portNum);
        string outputtxt = "port_" +to_string(portNum) + "_output.txt";
        cout<< "Create ouput file: "<< outputtxt <<"\n" <<std::endl;
        ofstream ofresult(outputtxt);
        std::cout << "------------------- Bosch Rexroth LLS Binary Interface " << "---------------------" << std::endl;

        //PoseMessage poseMessage;
        int32_t rv = 0;
        while (rv >= 0)
        {
            //rv = client.read(&poseMessage, sizeof(poseMessage));
            
            uint32_t map_length;
            client.read(&map_length,4);
            cout<<"current system time :"<< getCurrentSystemTime() <<endl;
            cout<<"map_length = "<<map_length<<"(points)"<<endl;
            scan_points_position.clear();
            for(int i = 0;i <map_length;i++)
            {
                float x,y;
                client.read(&x,4);
                client.read(&y,4);
                scan_points_position.push_back(make_pair(x,y));
                
            }
            // output the scan element
            ofresult << "time:"<<getCurrentSystemTime() << ":map_length:"<< map_length <<endl;
            for(int i = 0; i < scan_points_position.size(); i++){
                ofresult << scan_points_position[i].first << ", " << scan_points_position[i].second << endl;
                }
         
            std::cout << "----------------------------------------" << std::endl;
        }

        std::cout << "Socket call __read__ returned with signal: Socket closed." << std::endl;
        ofresult << flush;
        ofresult.close();
    }
    catch(std::exception& ex)
    {
        std::cerr << "Error during TCP Receiving test: " << std::string(ex.what()) << std::endl;
    }

}


// 9010
void BinaryInterface_loc_visu (const std::string &hostName,int portNum)
{   
    try
    {
        cout <<"Connect to Binary Interface "<<  portNum<<"."<< endl;
        BinaryInterfaceClient client(hostName, portNum);
        string outputtxt = "port_" +to_string(portNum) + "_output.txt";
        cout<< "Create ouput file: "<< outputtxt <<std::endl;
        ofstream ofresult(outputtxt);
        std::cout << "------------------- Bosch Rexroth LLS Binary Interface "<<"---------------------" << std::endl;
        ClientLocalizationVisualizationDatagram locvisudata;
        //PoseMessage poseMessage;
        int32_t rv = 0;
        while (rv >= 0)
        {
             rv = client.read(&locvisudata, sizeof(locvisudata));
            //std::cout<< "rv valus"<<rv<<std::endl;
            if (rv > 0)
            {   time_t diagnos_info_time = locvisudata.timestamp;
                //std::cout<<"Time（UTC/GMT+08:00）="<<ctime(&diagnos_info_time);
                cout << "timestamp  = "<<setprecision(13) << locvisudata.timestamp  << endl;
                ofresult << "timestamp:" <<setprecision(13) << locvisudata.timestamp  << endl;
                cout << "uniqueId = " << locvisudata.uniqueId << endl;
                cout << "locState  = " << locvisudata.locState  << endl;
                cout << "poseX  = " << locvisudata.poseX  << endl;
                ofresult << "poseX:" << locvisudata.poseX  << endl;
                cout << "poseY = " << locvisudata.poseY  << endl;
                ofresult << "poseY:" << locvisudata.poseY  << endl;
                cout << "poseYaw   = " << locvisudata.poseYaw         << endl;
                cout << "delay = " << locvisudata.delay         << endl;
                
            }  
            //scan: A 2D point cloud representing the most recent laser scan, given in the current map frame
            uint32_t scan_length;
            client.read(&scan_length,4);
            cout<<"current system time :"<< getCurrentSystemTime() <<endl;
            cout<<"scan->length = "<<scan_length<<" (points)"<<endl;
            scan_points_position.clear();
            for(int i = 0;i <scan_length;i++)
            {
                float x,y;
                client.read(&x,4);
                client.read(&y,4);
                scan_points_position.push_back(make_pair(x,y));
                
            }
            // output the scan element
            /*
            ofresult << "time:"<<getCurrentSystemTime()<<endl;
            for(int i = 0; i < scan_points_position.size(); i++){
                ofresult << scan_points_position[i].first << ", " << scan_points_position[i].second << endl;
                }
            */
            std::cout << "----------------------------------------" << std::endl;
        }

        std::cout << "Socket call __read__ returned with signal: Socket closed." << std::endl;
        ofresult << flush;
        ofresult.close();
    }
    catch(std::exception& ex)
    {
        std::cerr << "Error during TCP Receiving test: " << std::string(ex.what()) << std::endl;
    }

}


// 9011
void BinaryInterface_loc_pose (const std::string &hostName,int portNum)
{   
    try
    {
        cout <<"Connect to Binary Interface "<<  portNum<<"."<< endl;
        BinaryInterfaceClient client(hostName, portNum);
        string outputtxt = "port_" +to_string(portNum) + "_output.txt";
        cout<< "Create ouput file: "<< outputtxt <<"\n"<<std::endl;
        ofstream ofresult(outputtxt);
        std::cout << "------------------- Bosch Rexroth LLS Binary Interface "<<"---------------------" << std::endl;
        ClientLocalizationPoseDatagram locposedata;
        //PoseMessage poseMessage;
        int32_t rv = 0;
        while (rv >= 0)
        {
             rv = client.read(&locposedata, sizeof(locposedata));
            //std::cout<< "rv valus"<<rv<<std::endl;
            if (rv > 0)
            {   
                
                time_t diagnos_info_time = locposedata.timestamp;
                std::cout<<"Time（UTC/GMT+08:00）="<<ctime(&diagnos_info_time);
                
                cout << "age = " << locposedata.age <<endl;
                cout << "timestamp  = "<<setprecision(13) << locposedata.timestamp  << endl;
                ofresult << "timestamp:" <<setprecision(13) << locposedata.timestamp  << endl;
                cout << "uniqueId = " << locposedata.uniqueId << endl;
                cout << "state  = " << locposedata.state  << endl;
                cout << "poseX  = " << locposedata.poseX  << endl;
                ofresult << "poseX:" << locposedata.poseX  << endl;
                cout << "poseY = " << locposedata.poseY  << endl;
                ofresult << "poseY:" << locposedata.poseY  << endl;
                cout << "poseYaw   = " << locposedata.poseYaw  << endl;
                cout << "poseZ = " << locposedata.poseZ << endl;
                cout << "quaternion_w = " << locposedata.quaternion_w << endl;
                cout << "quaternion_x = " << locposedata.quaternion_x << endl;
                cout << "quaternion_y = " << locposedata.quaternion_y << endl;
                cout << "quaternion_z = " << locposedata.quaternion_z << endl;
                cout << "epoch = " << locposedata.epoch << endl;
                cout << "lidarOdoPoseX = " << locposedata.lidarOdoPoseX << endl;
                cout << "lidarOdoPoseY = " << locposedata.lidarOdoPoseY << endl;
                cout << "lidarOdoPoseYaw = " << locposedata.lidarOdoPoseYaw << endl;

            }  
         
            std::cout << "----------------------------------------" << std::endl;
        }

        std::cout << "Socket call __read__ returned with signal: Socket closed." << std::endl;
        ofresult << flush;
        ofresult.close();
    }
    catch(std::exception& ex)
    {
        std::cerr << "Error during TCP Receiving test: " << std::string(ex.what()) << std::endl;
    }

}

int main(int argc, char **argv)

{

    int portNum;
    cout << "Connect to port : ";
    cin >> portNum;
    cout<< "" << endl;



    if (portNum == 9004){
        cout<<"Port 9004 provides info about the current operating mode of the Localization Client"<<std::endl;
        BinaryInterface_control("localhost",portNum);
    }
    else if (portNum == 9005)
    {
        cout << "Port 9005 provides the current state of the map that is being built. (Botton: Create Map From Recording)"<< endl;
        BinaryInterface_map_rec_loc_map("localhost",portNum);
    }
    else if (portNum == 9006)
    {
        cout << "Port 9006 provides info needed to visualize and evaluate the current map building process. (Botton: Create Map From Recording)"<< endl;
        BinaryInterface_map_rec_visu("localhost",portNum);
    }
    else if (portNum == 9007)
    {
        cout << "Port 9007 provides current state of the map that could be generated using this recording (Botton: Start Visual Recording)"<< endl;
        BinaryInterface_map_rec_loc_map("localhost",portNum);
    }
    else if (portNum == 9008)
    {
        cout << "Port 9008 provides info needed to visualize and evaluate the current recording process (Botton: Start Visual Recording)"<< endl;
        BinaryInterface_map_rec_visu("localhost", portNum);
    }
    else if (portNum == 9009)
    {
        cout << "Port 9009 provides the map that is currently used for self-localization (Botton: Start Localization)"<< endl;
        BinaryInterface_map_rec_loc_map("localhost",portNum);
    }    
    else if (portNum == 9010)
    {
        cout << "Port 9010 provides info needed to visualize and evaluate the localization process (Botton: Start Localization)"<< endl;
        BinaryInterface_loc_visu("localhost",portNum);
    }
    else if (portNum == 9011)
    {
        cout << "Port 9011 provides continuous absolute and relative 2D planar poses"<< endl;
        BinaryInterface_loc_pose("localhost",portNum);
    }

    

    return 0;
}
