Locator中Binary接口的C++实现（除了9012）
1： g++ 直接编译
2： 输入需要监听的port，根据提示调整Locator到相应模式，数据会存储到相应的 .txt文件中
3： 对于输出点云地图的port （9005 9007 9009），用plot_point_cloud_from_port9007.py 可以分别绘制每一次更新的地图。记得修改txt文件路径。
