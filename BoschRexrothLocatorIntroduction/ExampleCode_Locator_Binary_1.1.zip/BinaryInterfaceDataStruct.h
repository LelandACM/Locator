/*
 * File: BinaryInterfacePoseStruct.h
 * Created On: 2019-03-13
 * Copyright © 2019 Bosch Rexroth AG
*/


// for port 9010
struct __attribute__ ((packed)) ClientControlModeDatagram
{
    uint32_t controlMode {0};
};

/*
 * structure containing part of message from ClientMapVisualizationDatagram and  ClientRecordingVisualizationDatagram
 */
//for port 9006 & 9008
struct __attribute__ ((packed)) Client_Map_Recording_VisualizationDatagram
{

    double   timestamp {0.};
    uint64_t visualizationld  {0};
    int32_t  status  {0};
    double   poseX        ;
    double   poseY        ;
    double   poseYaw       {0.};
    double   distanceToLastLC        {0.};
    double   delay        {0.};
    double   progress        {0.};
    /*
    array scan
    array pathPoses
    array pathTypes
    */

};

// for port 9010
struct __attribute__ ((packed)) ClientLocalizationVisualizationDatagram
{
    double   timestamp {0.};
    uint64_t uniqueId  {0};
    int32_t  locState  {0};
    double   poseX     {0};
    double   poseY     {0};
    double   poseYaw   {0.};
    double   delay     {0.};
    
    /*
    array scan  
    */

};

// for port 9011
struct __attribute__ ((packed)) ClientLocalizationPoseDatagram
{
    double   age       {0.};
    double   timestamp {0.};
    uint64_t uniqueId  {0};
    int32_t  state  {0};
    double   poseX     {0};
    double   poseY     {0};
    double   poseYaw   {0.};
    double   poseZ     {0.};
    double   quaternion_w     {0.};
    double   quaternion_x     {0.};
    double   quaternion_y     {0.};
    double   quaternion_z     {0.};
    uint64_t epoch  {0};
    double   lidarOdoPoseX     {0.};
    double   lidarOdoPoseY     {0.};
    double   lidarOdoPoseZ     {0.};
    double   lidarOdoPoseYaw     {0.};

};

