#ifndef ImuSERVER_H
#define ImuSERVER_H

#include "ros/ros.h"
#include "sensor_msgs/Imu.h"
#include "msg2tcp/BinaryInterfaceServer.h"
#include "msg2tcp/ImuMessage.h"

class ImuServer {
  public:
    ImuServer(int port); 
    void updateImu(const ImuMessage imu_message);

  private:
    int port_;
    int imu_number_;
    BinaryInterfaceServer* server_;
   
};



#endif
