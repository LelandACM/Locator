#include "ros/ros.h"
#include "sensor_msgs/Imu.h"
#include "std_msgs/String.h"
#include "msg2tcp/BinaryInterfaceServer.h"
#include "msg2tcp/ImuServer.h"
#include "tf/transform_datatypes.h"
//Open the socket

ImuServer::ImuServer(int port): port_(port), imu_number_(0){
  server_ = new BinaryInterfaceServer(port);
}


void ImuServer::updateImu(const ImuMessage imu_message) {
  //Imu_number_++;
  ImuMessage data = imu_message;
  server_->write(&data, sizeof(data)); //  server_->write(&data, sizeof(data));
}


//Broadcast to all clients the Imu data 
uint16_t currentOdoNum {0};
void imuCallback(const sensor_msgs::Imu::ConstPtr& msg, ImuServer* pToImuServer)
{
  ROS_INFO("trigger");
  const std::chrono::duration<double> unixTimePoint = std::chrono::system_clock::now() - std::chrono::system_clock::time_point ();
  ImuMessage imu_message;
  imu_message.imu_number = ++currentOdoNum;
  imu_message.timestamp = unixTimePoint.count();  
  //Imu_message.timestamp = msg->header.stamp.toSec();
  imu_message.orientation_qx = msg->orientation.x;
  imu_message.orientation_qy = msg->orientation.y;
  imu_message.orientation_qz = msg->orientation.z;
  imu_message.orientation_qw = msg->orientation.w;
  imu_message.omega_x = msg->angular_velocity.x;
  imu_message.omega_y = msg->angular_velocity.y;
  imu_message.omega_z = msg->angular_velocity.z;
  imu_message.a_x = msg->linear_acceleration.x;
  imu_message.a_y = msg->linear_acceleration.y;
  imu_message.a_z = msg->linear_acceleration.z;
  imu_message.orientation_set= false;
  imu_message.linearacc_set= false;
  
  //imu_message.yaw = tf::getYaw(msg->pose.pose.orientation);

  //check time
  printf("The time stamp is %f\n", imu_message.timestamp);
  printf("The orientation is %f\n %f\n %f\n %f\n ", imu_message.orientation_qx, imu_message.orientation_qy, imu_message.orientation_qz, imu_message.orientation_qw);
  
  pToImuServer->updateImu(imu_message);
}

int main(int argc, char **argv)
{
	ros::init(argc, argv, "imu2tcp_node");

	ros::NodeHandle n("~");


    int port = 9091;
    std::string imu_topic = "imu";
    // std_msgs::String ip;

    if (n.getParam("port", port))
    {
      ROS_INFO("Got 'port' param: %d", port);
    }
    else
    {
      ROS_ERROR("Failed to get param 'port'");
    }

    if (n.getParam("imu_topic", imu_topic))
    {
      ROS_INFO("Got 'imu_topic' param: %s", imu_topic.c_str());

    }
    else
    {
      ROS_ERROR("Failed to get param 'imu_topic'");

    }

    // ImuServer* Imu_server_ptr = newImue(port);
    ImuServer* pToImuServer = new ImuServer(port);

    //Subscribe to Imu topic
    ros::Subscriber sub = n.subscribe<sensor_msgs::Imu> (imu_topic, 1000, boost::bind(&imuCallback, _1, pToImuServer) );
    //Open socket of choice

    ros::spin();


    return 0;

}


